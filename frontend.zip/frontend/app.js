// ======================== Money Manager - Pure JavaScript ========================
// No backend required - uses localStorage for data persistence

// ---------- Storage Layer ----------
const DB_PATH = "db.json";
const Storage = {
  TRANSACTIONS_KEY: "money_manager_transactions",
  BUDGETS_KEY: "money_manager_budgets",
  DB_DATA_KEY: "money_manager_db",
  dbData: null,
  isDbLoaded: false,

  // Load db.json from server
  async loadDb() {
    try {
      const response = await fetch(DB_PATH);
      if (response.ok) {
        this.dbData = await response.json();
        this.isDbLoaded = true;
        // Cache in localStorage for offline use
        localStorage.setItem(this.DB_DATA_KEY, JSON.stringify(this.dbData));
        return true;
      }
    } catch (e) {
      console.warn("Could not load db.json, using localStorage cache:", e);
    }
    // Fallback to cached data
    try {
      const cached = localStorage.getItem(this.DB_DATA_KEY);
      if (cached) {
        this.dbData = JSON.parse(cached);
        this.isDbLoaded = true;
        return true;
      }
    } catch (e) {
      console.error("Error reading cached db:", e);
    }
    this.dbData = { transactions: [], budgets: {}, categories: {}, settings: {} };
    return false;
  },

  // Save db.json data back to localStorage cache
  saveDb() {
    try {
      if (this.dbData) {
        this.dbData.last_updated = new Date().toISOString();
        localStorage.setItem(this.DB_DATA_KEY, JSON.stringify(this.dbData));
      }
    } catch (e) {
      console.error("Error saving db:", e);
    }
  },

  // Export full database as downloadable JSON
  exportDb() {
    const data = {
      transactions: this.getTransactions(),
      budgets: this.getBudgets(),
      exported_at: new Date().toISOString(),
      app_name: "Money Manager"
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `money-manager-backup-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    return true;
  },

  // Import database from JSON file
  async importDb(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = JSON.parse(e.target.result);
          if (data.transactions && Array.isArray(data.transactions)) {
            this.saveTransactions(data.transactions);
          }
          if (data.budgets && Array.isArray(data.budgets)) {
            this.saveBudgets(data.budgets);
          }
          resolve({ success: true, message: "Data imported successfully" });
        } catch (err) {
          reject({ success: false, message: "Invalid JSON file" });
        }
      };
      reader.onerror = () => reject({ success: false, message: "Error reading file" });
      reader.readAsText(file);
    });
  },

  getTransactions() {
    try {
      const data = localStorage.getItem(this.TRANSACTIONS_KEY);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      console.error("Error reading transactions:", e);
      return [];
    }
  },

  saveTransactions(transactions) {
    try {
      // Save to localStorage
      localStorage.setItem(this.TRANSACTIONS_KEY, JSON.stringify(transactions));
      // Also save to JSON database cache
      if (this.dbData) {
        this.dbData.transactions = transactions;
        this.dbData.last_updated = new Date().toISOString();
        localStorage.setItem(this.DB_DATA_KEY, JSON.stringify(this.dbData));
      }
      return true;
    } catch (e) {
      console.error("Error saving transactions:", e);
      return false;
    }
  },

  getBudgets() {
    try {
      const data = localStorage.getItem(this.BUDGETS_KEY);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      console.error("Error reading budgets:", e);
      return [];
    }
  },

  saveBudgets(budgets) {
    try {
      // Save to localStorage
      localStorage.setItem(this.BUDGETS_KEY, JSON.stringify(budgets));
      // Also save to JSON database cache
      if (this.dbData) {
        this.dbData.budgets = budgets;
        this.dbData.last_updated = new Date().toISOString();
        localStorage.setItem(this.DB_DATA_KEY, JSON.stringify(this.dbData));
      }
      return true;
    } catch (e) {
      console.error("Error saving budgets:", e);
      return false;
    }
  },

  generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2, 9);
  }
};

// ---------- Category metadata ----------
const CATEGORIES = {
  salary: { label: "Salary", icon: "bi-cash-coin", color: "#10b981", types: ["income"] },
  freelance: { label: "Freelance", icon: "bi-laptop", color: "#0ea5e9", types: ["income"] },
  investment: { label: "Investment", icon: "bi-graph-up-arrow", color: "#8b5cf6", types: ["income"] },
  shopping: { label: "Shopping", icon: "bi-bag", color: "#f43f5e", types: ["expense"] },
  "eid-shopping": { label: "Eid Shopping", icon: "bi-gift", color: "#f59e0b", types: ["expense"] },
  groceries: { label: "Groceries", icon: "bi-basket", color: "#22c55e", types: ["expense"] },
  vegetables: { label: "Vegetables", icon: "bi-flower1", color: "#84cc16", types: ["expense"] },
  medicine: { label: "Medicine", icon: "bi-capsule", color: "#ef4444", types: ["expense"] },
  fish: { label: "Fish", icon: "bi-water", color: "#06b6d4", types: ["expense"] },
  meat: { label: "Meat", icon: "bi-bacon", color: "#f97316", types: ["expense"] },
  food: { label: "Food", icon: "bi-egg-fried", color: "#eab308", types: ["expense"] },
  snack: { label: "Snack", icon: "bi-cup-hot", color: "#d946ef", types: ["expense"] },
  lunch: { label: "Lunch", icon: "bi-egg", color: "#a16207", types: ["expense"] },
  dinner: { label: "Dinner", icon: "bi-moon-stars", color: "#7c3aed", types: ["expense"] },
  drink: { label: "Drink", icon: "bi-cup-straw", color: "#0d9488", types: ["expense"] },
  asset: { label: "Asset", icon: "bi-box-seam", color: "#6366f1", types: ["expense"] },
  "kitchen-item": { label: "Kitchen Item", icon: "bi-basket2", color: "#a3e635", types: ["expense"] },
  transport: { label: "Transport", icon: "bi-bus-front", color: "#0284c7", types: ["expense"] },
  utilities: { label: "Utilities", icon: "bi-lightning-charge", color: "#f59e0b", types: ["expense"] },
  entertainment: { label: "Entertainment", icon: "bi-controller", color: "#ec4899", types: ["expense"] },
  "household-expense": { label: "Household", icon: "bi-house", color: "#64748b", types: ["expense"] },
  "self-care-expense": { label: "Self Care", icon: "bi-scissors", color: "#f472b6", types: ["expense"] },
  other: { label: "Other", icon: "bi-three-dots", color: "#94a3b8", types: ["income", "expense"] },
};

function catMeta(category) {
  return CATEGORIES[String(category || "").toLowerCase()] || {
    label: category || "Other",
    icon: "bi-tag",
    color: "#94a3b8",
    types: ["income", "expense"],
  };
}

// ---------- State ----------
const state = {
  view: "dashboard",
  transactions: [],
  budgets: [],
  budgetMonth: currentMonthKey(),
  reportMonth: currentMonthKey(),
  reportTab: "monthly",
  editingTransactionId: null,
  editingBudgetId: null,
  txType: "income",
  charts: {},
  txModal: null,
  budgetModal: null,
};

// ---------- Helpers ----------
function currentMonthKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

function formatCurrency(amount) {
  const n = Number(amount) || 0;
  return (
    "\u09F3" +
    n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })
  );
}

function formatDate(dateString) {
  const d = new Date(dateString + "T00:00:00");
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

const MONTH_NAMES = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];

function monthLabel(monthKey) {
  const [y, m] = monthKey.split("-");
  return `${MONTH_NAMES[parseInt(m, 10) - 1]} ${y}`;
}

function shortMonthLabel(monthKey) {
  const [y, m] = monthKey.split("-");
  return `${MONTH_NAMES[parseInt(m, 10) - 1].slice(0, 3)} '${y.slice(2)}`;
}

function escapeHtml(str) {
  return String(str || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

let toastTimer = null;
function showToast(message, type = "success") {
  const toast = document.getElementById("toast");
  const icon = toast.querySelector("i");
  toast.className = "toast-app show " + type;
  icon.className =
    "bi " +
    (type === "success"
      ? "bi-check-circle-fill"
      : type === "error"
        ? "bi-x-circle-fill"
        : "bi-info-circle-fill");
  document.getElementById("toast-message").textContent = message;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2600);
}

// ======================== View switching ========================
function switchView(view) {
  state.view = view;
  const viewIds = {
    dashboard: "view-dashboard",
    transactions: "view-transactions",
    budgets: "view-budgets",
    reports: "view-reports",
  };

  Object.entries(viewIds).forEach(([key, id]) => {
    document.getElementById(id).classList.toggle("hide", key !== view);
  });

  document.querySelectorAll(".nav-link[data-view]").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.view === view);
  });
  document.querySelectorAll(".bn-item[data-view]").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.view === view);
  });

  switch (view) {
    case "dashboard":
      loadDashboard();
      break;
    case "transactions":
      loadTransactionsView();
      break;
    case "budgets":
      loadBudgetsView();
      break;
    case "reports":
      loadReportsView();
      break;
  }
}

// ======================== Dashboard ========================
function loadDashboard() {
  try {
    const summary = getSummary();
    const trends = getTrends(6);

    document.getElementById("total-income").textContent = formatCurrency(summary.total_income);
    document.getElementById("total-expense").textContent = formatCurrency(summary.total_expense);
    document.getElementById("total-saved").textContent = formatCurrency(summary.balance);
    document.getElementById("hero-balance").textContent = formatCurrency(summary.balance);

    // This month stats
    const currentMonth = currentMonthKey();
    let monthIncome = 0;
    let monthExpense = 0;
    state.transactions.forEach((t) => {
      if (String(t.date).slice(0, 7) === currentMonth) {
        if (t.type === "income") monthIncome += t.amount;
        else monthExpense += t.amount;
      }
    });
    document.getElementById("hero-income").textContent = formatCurrency(monthIncome);
    document.getElementById("hero-expense").textContent = formatCurrency(monthExpense);
    document.getElementById("hero-saving").textContent = formatCurrency(monthIncome - monthExpense);

    renderTrendChart(trends);
    renderCategoryChart(summary);

    // Recent transactions (top 6)
    const recent = [...state.transactions]
      .sort((a, b) => (b.date + b.created_at).localeCompare(a.date + a.created_at))
      .slice(0, 6);
    document.getElementById("recent-transactions").innerHTML =
      recent.length ? txnRows(recent) : emptyState("No transactions yet");

    // Budget preview
    renderDashboardBudgets();
  } catch (err) {
    console.error("Dashboard error:", err);
    showToast("Failed to load dashboard: " + err.message, "error");
  }
}

function renderDashboardBudgets() {
  try {
    const budgets = getBudgetsWithSpent(state.budgetMonth);
    const el = document.getElementById("dashboard-budgets");
    if (!budgets.length) {
      el.innerHTML =
        '<div class="empty-state"><i class="bi bi-pie-chart"></i><p>No budgets set yet.<br>Create one to start tracking.</p></div>';
      return;
    }
    el.innerHTML = budgets
      .slice(0, 4)
      .map(budgetRow)
      .join("");
  } catch (_) {
    document.getElementById("dashboard-budgets").innerHTML = emptyState("Could not load budgets");
  }
}

function renderTrendChart(trends) {
  const ctx = document.getElementById("trend-chart");
  if (state.charts.trend) state.charts.trend.destroy();

  state.charts.trend = new Chart(ctx, {
    type: "line",
    data: {
      labels: trends.map((t) => shortMonthLabel(t.month)),
      datasets: [
        {
          label: "Income",
          data: trends.map((t) => t.income),
          borderColor: "#10b981",
          backgroundColor: "rgba(16, 185, 129, 0.12)",
          fill: true,
          tension: 0.4,
          pointRadius: 3,
          pointBackgroundColor: "#10b981",
          borderWidth: 2.5,
        },
        {
          label: "Expense",
          data: trends.map((t) => t.expense),
          borderColor: "#f43f5e",
          backgroundColor: "rgba(244, 63, 94, 0.10)",
          fill: true,
          tension: 0.4,
          pointRadius: 3,
          pointBackgroundColor: "#f43f5e",
          borderWidth: 2.5,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: "bottom",
          labels: { usePointStyle: true, pointStyle: "circle", padding: 16, font: { family: "Inter", size: 12 } },
        },
        tooltip: {
          callbacks: {
            label: (c) => ` ${c.dataset.label}: ${formatCurrency(c.raw)}`,
          },
        },
      },
      scales: {
        y: {
          beginAtZero: true,
          grid: { color: "#eef0f7" },
          ticks: {
            font: { family: "Inter", size: 11 },
            callback: (v) => (v >= 1000 ? `${(v / 1000).toFixed(0)}k` : v),
          },
        },
        x: {
          grid: { display: false },
          ticks: { font: { family: "Inter", size: 11 } },
        },
      },
    },
  });
}

function renderCategoryChart(summary) {
  const ctx = document.getElementById("category-chart");
  if (state.charts.category) state.charts.category.destroy();

  const entries = Object.entries(summary.expense_by_category || {}).sort((a, b) => b[1] - a[1]);
  const legendEl = document.getElementById("category-legend");

  if (!entries.length) {
    legendEl.innerHTML = '<p class="text-muted text-center mb-0">No expense data available</p>';
    if (ctx) {
      state.charts.category = new Chart(ctx, {
        type: "doughnut",
        data: { labels: [], datasets: [{ data: [], backgroundColor: [] }] },
        options: { responsive: true, maintainAspectRatio: false },
      });
    }
    return;
  }

  const total = entries.reduce((s, [, v]) => s + v, 0);
  const colors = entries.map(([cat]) => catMeta(cat).color);
  const labels = entries.map(([cat]) => catMeta(cat).label);

  state.charts.category = new Chart(ctx, {
    type: "doughnut",
    data: {
      labels,
      datasets: [{ data: entries.map(([, v]) => v), backgroundColor: colors, borderWidth: 2, borderColor: "#fff" }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: "68%",
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: (c) => ` ${c.label}: ${formatCurrency(c.raw)} (${((c.raw / total) * 100).toFixed(1)}%)`,
          },
        },
      },
    },
  });

  legendEl.innerHTML = entries
    .map(
      ([cat, value]) => `
      <div class="legend-row">
        <span class="dot" style="background:${catMeta(cat).color}"></span>
        <span class="l-label">${escapeHtml(catMeta(cat).label)}</span>
        <span class="l-pct">${((value / total) * 100).toFixed(1)}%</span>
        <span class="l-value">${formatCurrency(value)}</span>
      </div>`
    )
    .join("");
}

// ======================== Transaction rows ========================
function txnRows(transactions) {
  return transactions
    .map((t) => {
      const meta = catMeta(t.category);
      const isIncome = t.type === "income";
      const id = t.id;
      return `
      <div class="txn-row">
        <div class="txn-avatar" style="background:${meta.color}">
          <i class="bi ${meta.icon}"></i>
        </div>
        <div class="txn-info">
          <div class="txn-title">${escapeHtml(t.description || meta.label)}</div>
          <div class="txn-sub">
            <span class="cat-badge" style="background:${meta.color}18;color:${meta.color}">
              <i class="bi ${meta.icon}"></i> ${escapeHtml(meta.label)}
            </span>
          </div>
        </div>
        <div class="txn-amount">
          <div class="amount ${isIncome ? "in" : "out"}">${isIncome ? "+" : "\u2212"}${formatCurrency(t.amount)}</div>
          <div class="date">${formatDate(t.date)}</div>
        </div>
        <div class="txn-actions">
          <button class="icon-btn" title="Edit" onclick="openTransactionModal('${id}')">
            <i class="bi bi-pencil"></i>
          </button>
          <button class="icon-btn danger" title="Delete" onclick="deleteTransaction('${id}')">
            <i class="bi bi-trash"></i>
          </button>
        </div>
      </div>`;
    })
    .join("");
}

function emptyState(text) {
  return `<div class="empty-state"><i class="bi bi-inbox"></i><p>${text}</p></div>`;
}

// ======================== Transactions view ========================
function loadTransactionsView() {
  try {
    populateCategoryFilter();
    applyTransactionFilters();
  } catch (err) {
    console.error("Transactions error:", err);
    showToast("Failed to load transactions: " + err.message, "error");
  }
}

function populateCategoryFilter() {
  const select = document.getElementById("txn-category-filter");
  const categories = [...new Set(state.transactions.map((t) => t.category.toLowerCase()))].sort();
  const current = select.value;
  select.innerHTML = `<option value="">All Categories</option>` +
    categories.map((c) => `<option value="${escapeHtml(c)}">${escapeHtml(catMeta(c).label)}</option>`).join("");
  select.value = current;
}

function applyTransactionFilters() {
  const search = (document.getElementById("txn-search").value || "").toLowerCase().trim();
  const type = document.getElementById("txn-type-filter").value;
  const category = document.getElementById("txn-category-filter").value;
  const month = document.getElementById("txn-month-filter").value;

  const filtered = state.transactions.filter((t) => {
    if (search && !(t.description || "").toLowerCase().includes(search)) return false;
    if (type && t.type !== type) return false;
    if (category && t.category.toLowerCase() !== category) return false;
    if (month && String(t.date).slice(0, 7) !== month) return false;
    return true;
  });

  const sorted = [...filtered].sort((a, b) =>
    (b.date + (b.created_at || "")).localeCompare(a.date + (a.created_at || ""))
  );

  const totalIn = filtered.filter((t) => t.type === "income").reduce((s, t) => s + t.amount, 0);
  const totalOut = filtered.filter((t) => t.type === "expense").reduce((s, t) => s + t.amount, 0);

  document.getElementById("txn-count").textContent = `${filtered.length} transaction${filtered.length === 1 ? "" : "s"}`;
  document.getElementById("txn-total-income").textContent = `In: ${formatCurrency(totalIn)}`;
  document.getElementById("txn-total-expense").textContent = `Out: ${formatCurrency(totalOut)}`;

  document.getElementById("transactions-list").innerHTML = sorted.length
    ? txnRows(sorted)
    : emptyState("No transactions match your filters");
}

function refreshTransactions() {
  state.transactions = Storage.getTransactions();
}

// ======================== Add / Edit transaction ========================
function openTransactionModal(id) {
  state.editingTransactionId = id || null;
  const editing = id ? state.transactions.find((t) => t.id === id) : null;

  document.getElementById("transaction-modal-title").textContent = editing
    ? "Edit Transaction"
    : "Add Transaction";

  setTxType(editing ? editing.type : "income");
  renderCategoryPicker(editing ? editing.type : state.txType, editing ? editing.category : null);
  document.getElementById("tx-amount").value = editing ? editing.amount : "";
  document.getElementById("tx-date").value = editing ? editing.date : new Date().toISOString().slice(0, 10);
  document.getElementById("tx-description").value = editing ? editing.description || "" : "";
  document.getElementById("tx-submit-btn").innerHTML = editing
    ? '<i class="bi bi-check-lg me-1"></i> Update'
    : '<i class="bi bi-check-lg me-1"></i> Save';

  if (!state.txModal) {
    state.txModal = new bootstrap.Modal(document.getElementById("transaction-modal"));
  }
  state.txModal.show();
}

function setTxType(type) {
  state.txType = type === "expense" ? "expense" : "income";
  document.getElementById("tx-type-income").classList.toggle("active", state.txType === "income");
  document.getElementById("tx-type-expense").classList.toggle("active", state.txType === "expense");
}

function renderCategoryPicker(type, selected) {
  const container = document.getElementById("category-picker");
  const cats = Object.entries(CATEGORIES).filter(([, meta]) => meta.types.includes(type));
  container.innerHTML = cats
    .map(
      ([key, meta]) => `
      <button type="button" class="category-chip ${selected === key ? "selected" : ""}" data-cat="${key}" onclick="selectTxCategory('${key}')">
        <span class="cc-avatar" style="background:${meta.color}"><i class="bi ${meta.icon}"></i></span>
        <span class="cc-label">${meta.label}</span>
      </button>`
    )
    .join("");
}

function selectTxCategory(key) {
  document.querySelectorAll("#category-picker .category-chip").forEach((chip) => {
    chip.classList.toggle("selected", chip.dataset.cat === key);
  });
}

function getSelectedCategory() {
  const chip = document.querySelector("#category-picker .category-chip.selected");
  return chip ? chip.dataset.cat : null;
}

function submitTransaction() {
  const category = getSelectedCategory();
  const amount = parseFloat(document.getElementById("tx-amount").value);
  const date = document.getElementById("tx-date").value;
  const description = document.getElementById("tx-description").value.trim();

  if (!category) return showToast("Please select a category", "error");
  if (!amount || amount <= 0) return showToast("Enter a valid amount", "error");
  if (!date) return showToast("Pick a date", "error");

  const payload = { type: state.txType, category, amount, date, description };
  const editingId = state.editingTransactionId;

  try {
    if (editingId) {
      // Update existing transaction
      const index = state.transactions.findIndex((t) => t.id === editingId);
      if (index !== -1) {
        state.transactions[index] = {
          ...state.transactions[index],
          ...payload,
          category: payload.category.toLowerCase(),
          type: payload.type.toLowerCase(),
        };
        Storage.saveTransactions(state.transactions);
        showToast("Transaction updated");
      }
    } else {
      // Create new transaction
      const newTransaction = {
        id: Storage.generateId(),
        type: payload.type.toLowerCase(),
        category: payload.category.toLowerCase(),
        amount: payload.amount,
        date: payload.date,
        description: payload.description,
        created_at: new Date().toISOString().replace("T", " ").slice(0, 19),
      };
      state.transactions.push(newTransaction);
      Storage.saveTransactions(state.transactions);
      showToast("Transaction added");
    }

    state.txModal.hide();
    if (state.view === "dashboard") loadDashboard();
    else if (state.view === "transactions") applyTransactionFilters();
  } catch (err) {
    showToast(err.message, "error");
  }
}

function deleteTransaction(id) {
  if (!confirm("Delete this transaction?")) return;
  try {
    state.transactions = state.transactions.filter((t) => t.id !== id);
    Storage.saveTransactions(state.transactions);
    showToast("Transaction deleted");
    if (state.view === "dashboard") loadDashboard();
    else if (state.view === "transactions") applyTransactionFilters();
  } catch (err) {
    showToast(err.message, "error");
  }
}

// ======================== Budgets ========================
function budgetRow(b) {
  const meta = catMeta(b.category);
  const pct = Math.min(b.percent, 100);
  const over = b.spent > b.amount;
  const warn = !over && b.percent >= 80;
  const barColor = over ? "#f43f5e" : warn ? "#f59e0b" : "#6366f1";
  const status = over
    ? `<span class="text-danger fw-bold">Over by ${formatCurrency(b.spent - b.amount)}</span>`
    : warn
      ? `<span class="text-warning fw-bold">Getting close</span>`
      : `<span>${formatCurrency(b.remaining)} left</span>`;

  return `
    <div class="budget-item">
      <div class="budget-head">
        <div class="b-left">
          <span class="txn-avatar" style="width:36px;height:36px;font-size:15px;background:${meta.color}">
            <i class="bi ${meta.icon}"></i>
          </span>
          <div>
            <div class="b-title">${escapeHtml(meta.label)} ${b.month ? `<span class="cat-badge" style="background:var(--primary-light);color:var(--primary)">${escapeHtml(monthLabel(b.month))}</span>` : ""}</div>
            <div class="b-sub">${formatCurrency(b.spent)} of ${formatCurrency(b.amount)}</div>
          </div>
        </div>
        <div class="b-right">${status}</div>
        <div class="txn-actions">
          <button class="icon-btn" title="Edit" onclick="openBudgetModal('${b.id}')"><i class="bi bi-pencil"></i></button>
          <button class="icon-btn danger" title="Delete" onclick="deleteBudget('${b.id}')"><i class="bi bi-trash"></i></button>
        </div>
      </div>
      <div class="progress-app">
        <div class="bar" style="width:${pct}%;background:${barColor}"></div>
      </div>
    </div>`;
}

function loadBudgetsView() {
  try {
    const budgets = getBudgetsWithSpent(state.budgetMonth);
    state.budgets = budgets;
    document.getElementById("budget-month-label").textContent = monthLabel(state.budgetMonth);

    const totalAmount = budgets.reduce((s, b) => s + b.amount, 0);
    const totalSpent = budgets.reduce((s, b) => s + b.spent, 0);
    const totalPct = totalAmount ? (totalSpent / totalAmount) * 100 : 0;

    document.getElementById("budget-total-label").textContent = "Total Budget";
    document.getElementById("budget-total-sub").textContent = `${budgets.length} categor${budgets.length === 1 ? "y" : "ies"} tracked`;
    document.getElementById("budget-total-amount").textContent = `${formatCurrency(totalSpent)} / ${formatCurrency(totalAmount)}`;
    document.getElementById("budget-total-status").textContent =
      totalSpent > totalAmount ? "Over budget!" : `${formatCurrency(totalAmount - totalSpent)} remaining`;
    const bar = document.getElementById("budget-total-bar");
    bar.style.width = `${Math.min(totalPct, 100)}%`;
    bar.style.background = totalSpent > totalAmount ? "#f43f5e" : totalPct >= 80 ? "#f59e0b" : "#6366f1";

    document.getElementById("budgets-list").innerHTML = budgets.length
      ? budgets.map(budgetRow).join("")
      : emptyState("No budgets yet. Add one to control your spending.");
  } catch (err) {
    showToast("Failed to load budgets: " + err.message, "error");
  }
}

function navigateBudgetMonth(direction) {
  const [y, m] = state.budgetMonth.split("-").map(Number);
  const d = new Date(y, m - 1 + direction, 1);
  state.budgetMonth = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
  loadBudgetsView();
}

function openBudgetModal(id) {
  state.editingBudgetId = id || null;
  const editing = id ? state.budgets.find((b) => b.id === id) : null;

  document.getElementById("budget-modal-title").textContent = editing ? "Edit Budget" : "Add Budget";

  const select = document.getElementById("budget-category");
  select.innerHTML =
    `<option value="">Select category</option>` +
    Object.entries(CATEGORIES)
      .filter(([, meta]) => meta.types.includes("expense"))
      .map(([key, meta]) => `<option value="${key}">${meta.label}</option>`)
      .join("");

  document.getElementById("budget-amount").value = editing ? editing.amount : "";
  document.getElementById("budget-submit-btn").innerHTML = editing
    ? '<i class="bi bi-check-lg me-1"></i> Update'
    : '<i class="bi bi-check-lg me-1"></i> Save';

  if (editing) {
    select.value = editing.category;
    const recurring = !editing.month;
    document.getElementById("budget-recurring").checked = recurring;
    document.getElementById("budget-month").value = editing.month || state.budgetMonth;
    toggleBudgetMonthWrap();
  } else {
    document.getElementById("budget-recurring").checked = true;
    document.getElementById("budget-month").value = state.budgetMonth;
    toggleBudgetMonthWrap();
  }

  if (!state.budgetModal) {
    state.budgetModal = new bootstrap.Modal(document.getElementById("budget-modal"));
  }
  state.budgetModal.show();
}

function toggleBudgetMonthWrap() {
  const recurring = document.getElementById("budget-recurring").checked;
  document.getElementById("budget-month-wrap").classList.toggle("hide", recurring);
}

function submitBudget() {
  const category = document.getElementById("budget-category").value;
  const amount = parseFloat(document.getElementById("budget-amount").value);
  const recurring = document.getElementById("budget-recurring").checked;
  const month = recurring ? "" : document.getElementById("budget-month").value;

  if (!category) return showToast("Select a category", "error");
  if (!amount || amount <= 0) return showToast("Enter a valid amount", "error");

  const editingId = state.editingBudgetId;

  try {
    if (editingId) {
      // Update existing budget
      const index = state.budgets.findIndex((b) => b.id === editingId);
      if (index !== -1) {
        state.budgets[index] = {
          ...state.budgets[index],
          category: category.toLowerCase(),
          amount: amount,
          month: month,
        };
        Storage.saveBudgets(state.budgets);
        showToast("Budget updated");
      }
    } else {
      // Check for duplicate
      const allBudgets = Storage.getBudgets();
      const duplicate = allBudgets.find(
        (b) => b.category === category.toLowerCase() && b.month === month
      );
      if (duplicate) {
        return showToast("A budget already exists for this category and month", "error");
      }

      // Create new budget
      const newBudget = {
        id: Storage.generateId(),
        category: category.toLowerCase(),
        amount: amount,
        month: month,
      };
      state.budgets.push(newBudget);
      Storage.saveBudgets(state.budgets);
      showToast("Budget created");
    }

    state.budgetModal.hide();
    loadBudgetsView();
    if (state.view === "dashboard") renderDashboardBudgets();
  } catch (err) {
    showToast(err.message, "error");
  }
}

function deleteBudget(id) {
  if (!confirm("Delete this budget?")) return;
  try {
    state.budgets = state.budgets.filter((b) => b.id !== id);
    Storage.saveBudgets(state.budgets);
    showToast("Budget deleted");
    loadBudgetsView();
    if (state.view === "dashboard") renderDashboardBudgets();
  } catch (err) {
    showToast(err.message, "error");
  }
}

// ======================== Reports ========================
function setReportTab(tab) {
  state.reportTab = tab;
  document.getElementById("report-monthly-tab").classList.toggle("active", tab === "monthly");
  document.getElementById("report-daily-tab").classList.toggle("active", tab === "daily");
  document.getElementById("report-monthly-section").classList.toggle("hide", tab !== "monthly");
  document.getElementById("report-daily-section").classList.toggle("hide", tab !== "daily");
  document.getElementById("report-month-nav").classList.toggle("hide", tab !== "daily");
  loadReportsView();
}

function loadReportsView() {
  if (state.reportTab === "monthly") {
    loadMonthlyReport();
  } else {
    document.getElementById("report-month-label").textContent = monthLabel(state.reportMonth);
    loadDailyReport();
  }
}

function loadMonthlyReport() {
  const body = document.getElementById("monthly-report-body");
  try {
    const monthly = getMonthlyReport();
    const sorted = Object.entries(monthly).sort((a, b) => b[0].localeCompare(a[0]));

    if (!sorted.length) {
      body.innerHTML = `<tr><td colspan="5" class="text-center text-muted py-4">No data available</td></tr>`;
      return;
    }

    body.innerHTML = sorted
      .map(([month, data]) => {
        const balanceClass = data.balance >= 0 ? "text-success" : "text-danger";
        return `
        <tr>
          <td class="fw-semibold">${escapeHtml(monthLabel(month))}</td>
          <td class="text-success fw-semibold">${formatCurrency(data.income)}</td>
          <td class="text-danger fw-semibold">${formatCurrency(data.expense)}</td>
          <td class="${balanceClass} fw-bold">${formatCurrency(data.balance)}</td>
          <td class="text-end">${data.transactions}</td>
        </tr>`;
      })
      .join("");
  } catch (err) {
    body.innerHTML = `<tr><td colspan="5" class="text-center text-danger py-4">Failed to load report</td></tr>`;
  }
}

function loadDailyReport() {
  const section = document.getElementById("report-daily-section");
  try {
    const daily = getDailyReport(state.reportMonth);
    const sorted = Object.entries(daily).sort((a, b) => b[0].localeCompare(a[0]));

    if (!sorted.length) {
      section.innerHTML = `<div class="card-app"><div class="card-body-app">${emptyState("No transactions for this month")}</div></div>`;
      return;
    }

    section.innerHTML = sorted
      .map(([date, data]) => {
        const details = data.details || [];
        return `
        <div class="day-card">
          <div class="day-head">
            <h6>${escapeHtml(formatDate(date))}</h6>
            <div class="d-flex gap-2 flex-wrap">
              <span class="cat-badge" style="background:var(--success-light);color:var(--success)">
                <i class="bi bi-arrow-down-circle"></i> ${formatCurrency(data.income)}
              </span>
              <span class="cat-badge" style="background:var(--danger-light);color:var(--danger)">
                <i class="bi bi-arrow-up-circle"></i> ${formatCurrency(data.expense)}
              </span>
              <span class="cat-badge" style="background:var(--primary-light);color:var(--primary)">
                <i class="bi bi-wallet2"></i> ${formatCurrency(data.balance)}
              </span>
            </div>
          </div>
          <div class="day-body">${txnRows(details)}</div>
        </div>`;
      })
      .join("");
  } catch (err) {
    section.innerHTML = `<div class="card-app"><div class="card-body-app"><p class="text-danger text-center mb-0">Failed to load daily report</p></div></div>`;
  }
}

function navigateReportMonth(direction) {
  const [y, m] = state.reportMonth.split("-").map(Number);
  const d = new Date(y, m - 1 + direction, 1);
  state.reportMonth = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
  loadDailyReport();
}

// ======================== Data Functions ========================
function getSummary() {
  const transactions = state.transactions;
  let totalIncome = 0;
  let totalExpense = 0;
  const categoryTotals = {};

  transactions.forEach((t) => {
    if (t.type === "income") {
      totalIncome += t.amount;
    } else if (t.type === "expense") {
      totalExpense += t.amount;
      categoryTotals[t.category] = (categoryTotals[t.category] || 0) + t.amount;
    }
  });

  return {
    total_income: totalIncome,
    total_expense: totalExpense,
    balance: totalIncome - totalExpense,
    expense_by_category: categoryTotals,
  };
}

function getTrends(months = 6) {
  const transactions = state.transactions;
  const now = new Date();
  const monthKeys = [];

  for (let i = months - 1; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    monthKeys.push(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`);
  }

  const trends = monthKeys.map((key) => ({
    month: key,
    income: 0,
    expense: 0,
    balance: 0,
  }));

  const indexByMonth = {};
  monthKeys.forEach((key, i) => {
    indexByMonth[key] = i;
  });

  transactions.forEach((t) => {
    if (t.date.length >= 7) {
      const monthKey = t.date.slice(0, 7);
      if (indexByMonth[monthKey] !== undefined) {
        const idx = indexByMonth[monthKey];
        if (t.type === "income") {
          trends[idx].income += t.amount;
        } else if (t.type === "expense") {
          trends[idx].expense += t.amount;
        }
        trends[idx].balance = trends[idx].income - trends[idx].expense;
      }
    }
  });

  return trends;
}

function getMonthlyReport() {
  const transactions = state.transactions;
  const monthlyData = {};

  transactions.forEach((t) => {
    if (t.date.length >= 7) {
      const month = t.date.slice(0, 7);
      if (!monthlyData[month]) {
        monthlyData[month] = { income: 0, expense: 0, transactions: 0, balance: 0 };
      }

      if (t.type === "income") {
        monthlyData[month].income += t.amount;
      } else {
        monthlyData[month].expense += t.amount;
      }
      monthlyData[month].transactions++;
      monthlyData[month].balance = monthlyData[month].income - monthlyData[month].expense;
    }
  });

  return monthlyData;
}

function getDailyReport(month) {
  const transactions = state.transactions.filter((t) => {
    if (month && t.date.length >= 7) {
      return t.date.slice(0, 7) === month;
    }
    return true;
  });

  const dailyData = {};

  transactions.forEach((t) => {
    const dateKey = t.date;
    if (!dailyData[dateKey]) {
      dailyData[dateKey] = { income: 0, expense: 0, transactions: 0, balance: 0, details: [] };
    }

    if (t.type === "income") {
      dailyData[dateKey].income += t.amount;
    } else {
      dailyData[dateKey].expense += t.amount;
    }
    dailyData[dateKey].transactions++;
    dailyData[dateKey].balance = dailyData[dateKey].income - dailyData[dateKey].expense;
    dailyData[dateKey].details.push(t);
  });

  return dailyData;
}

function getBudgetsWithSpent(month) {
  const budgets = state.budgets;
  const transactions = state.transactions;

  // Category spending for the month
  const spentByCategory = {};
  transactions.forEach((t) => {
    if (t.type === "expense" && t.date.length >= 7 && t.date.slice(0, 7) === month) {
      spentByCategory[t.category] = (spentByCategory[t.category] || 0) + t.amount;
    }
  });

  return budgets
    .filter((b) => {
      // A specific-month budget only counts for its own month
      if (b.month && b.month !== month) {
        return false;
      }
      return true;
    })
    .map((b) => {
      const spent = spentByCategory[b.category] || 0;
      return {
        id: b.id,
        category: b.category,
        amount: b.amount,
        month: b.month,
        spent: spent,
        remaining: b.amount - spent,
        percent: b.amount > 0 ? (spent / b.amount) * 100 : 0,
      };
    })
    .sort((a, b) => a.category.localeCompare(b.category));
}

// ======================== Init ========================
document.addEventListener("DOMContentLoaded", async function () {
  // Load db.json database first
  await Storage.loadDb();

  // Load data from localStorage
  state.transactions = Storage.getTransactions();
  state.budgets = Storage.getBudgets();

  // Navigation
  document.querySelectorAll(".nav-link[data-view]").forEach((btn) => {
    btn.addEventListener("click", () => switchView(btn.dataset.view));
  });
  document.querySelectorAll(".bn-item[data-view]").forEach((btn) => {
    btn.addEventListener("click", () => switchView(btn.dataset.view));
  });

  // Transaction modal
  document.getElementById("tx-type-income").addEventListener("click", () => {
    setTxType("income");
    renderCategoryPicker("income", getSelectedCategory());
  });
  document.getElementById("tx-type-expense").addEventListener("click", () => {
    setTxType("expense");
    renderCategoryPicker("expense", getSelectedCategory());
  });
  document.getElementById("tx-submit-btn").addEventListener("click", submitTransaction);

  // Budget modal
  document.getElementById("budget-recurring").addEventListener("change", toggleBudgetMonthWrap);
  document.getElementById("budget-submit-btn").addEventListener("click", submitBudget);

  // Budget month nav
  document.getElementById("budget-prev-month").addEventListener("click", () => navigateBudgetMonth(-1));
  document.getElementById("budget-next-month").addEventListener("click", () => navigateBudgetMonth(1));

  // Report nav
  document.getElementById("report-prev-month").addEventListener("click", () => navigateReportMonth(-1));
  document.getElementById("report-next-month").addEventListener("click", () => navigateReportMonth(1));

  // Transaction filters
  ["txn-search", "txn-type-filter", "txn-category-filter", "txn-month-filter"].forEach((id) => {
    document.getElementById(id).addEventListener("input", applyTransactionFilters);
  });

  // Load initial view
  switchView("dashboard");
});

// ======================== Export / Import ========================
function exportDatabase() {
  try {
    Storage.exportDb();
    showToast("Database exported successfully!");
  } catch (err) {
    showToast("Export failed: " + err.message, "error");
  }
}

async function importDatabase(event) {
  const file = event.target.files[0];
  if (!file) return;

  try {
    await Storage.importDb(file);
    state.transactions = Storage.getTransactions();
    state.budgets = Storage.getBudgets();
    showToast("Database imported successfully!");
    switchView(state.view);
  } catch (err) {
    showToast(err.message || "Import failed", "error");
  }
  event.target.value = "";
}

// Expose for inline onclick handlers
window.openTransactionModal = openTransactionModal;
window.openBudgetModal = openBudgetModal;
window.deleteTransaction = deleteTransaction;
window.deleteBudget = deleteBudget;
window.selectTxCategory = selectTxCategory;
window.switchView = switchView;
window.setReportTab = setReportTab;
window.exportDatabase = exportDatabase;
window.importDatabase = importDatabase;
